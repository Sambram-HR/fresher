package simple.c;

public class Domestic {

	public static void main(String[] args) {
		Animal a=new Animal();
		Cow c=new Cow();
		Dog d=new Dog();
		Home p=new Home();
		
		a.eat();
		a.sleep();
		System.out.println();
		
		c.eat();
		c.sleep();
		System.out.println();
		
		d.eat();
		d.sleep();
		//System.out.println();
		
		
	}

}
