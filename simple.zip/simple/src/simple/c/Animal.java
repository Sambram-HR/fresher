package simple.c;

public class Animal {
	void eat() {
		System.out.println("animal eats");
	}
	void sleep() {
		System.out.println("animal sleeps");
	}
}
