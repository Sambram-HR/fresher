package simple.c;

public class Dog extends Animal {
	void eat() {
		System.out.println("dog eats pedigree");
	}
	void sleep() {
		System.out.println("dog sleeps");
	}
}
