package simple.c;

public class Cow extends Animal {
	void eat() {
		System.out.println("cow eats grass");
	}
	void sleep() {
		System.out.println("cow sleeps");
	}
}
