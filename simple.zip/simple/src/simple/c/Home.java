package simple.c;

public class Home {
	void place(Animal p) {
		p.eat();
		p.sleep();
	}
}
